# ISM_PROJEKT_APIARY
Simulating an apiary to figure out whether onsite or offsite extraction is more effective.

`cd simlib`


`sudo make install`
